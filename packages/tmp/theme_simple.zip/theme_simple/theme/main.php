<html>
<head>
  <title><?php print self::_getConf('core', 'title') ?> <?php packages::call('page_header_title'); ?></title>
  <link rel='stylesheet' type='text/css' href='packages/theme_simple/theme/style.css' />
  <?php packages::call('page_header'); ?>
</head>
<body>
  <div class='wrapper'>
    <div class='header'>
      <b><?php print self::_getConf('core', 'title') ?></b>
    </div>
    <div class='menu'>
      <?php packages::call('page_menu_top'); ?>
    </div>
    <div class='content'>
      <?php packages::call('page_content'); ?>
    </div>
  </div>
  <div class='footer'> <?php packages::call('page_footer') ?> </div>
</body>
